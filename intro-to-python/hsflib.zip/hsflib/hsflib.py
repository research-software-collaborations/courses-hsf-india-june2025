import shapefile
import matplotlib.pyplot as plt

def load_shapefile():
    shapefile_path = 'hsflib/data/osm_land_polygons_simplifyGeom_0point005_areaGT1e6_aggregated.shp' 

    all_polygons_coords = []
    # Load the shapefile 
    try:
        sf = shapefile.Reader(shapefile_path)
    except shapefile.ShapefileException as e:
        print(f"Error reading shapefile: {e}")
        print("Check that all component files (.shp, .shx, .dbf) are present in the same directory.")
        exit()


    # Iterate through each shape (e.g., continent, island) in the shapefile
    for shape in sf.shapes():
        # shape.points contains a list of (x, y) tuples, where x is longitude and y is latitude
        # shape.parts indicates the start index of each part of a multi-part shape (e.g., a continent with islands)
    
        # Handle multi-part polygons (e.g., continents with multiple islands)
        if shape.parts:
            for i in range(len(shape.parts)):
                start_index = shape.parts[i]
                end_index = shape.parts[i+1] if i + 1 < len(shape.parts) else len(shape.points)
            
                # Extract points for this part
                part_points = shape.points[start_index:end_index]
                all_polygons_coords.append(part_points)
        else:
            # Single-part polygon
            all_polygons_coords.append(shape.points)
    return all_polygons_coords

def setup_map(all_polygons_coords):
    fig, ax = plt.subplots(figsize=(12, 8))

    for polygon_coords in all_polygons_coords:
        if not polygon_coords:
            continue # Skip empty parts

        lons = [p[0] for p in polygon_coords]
        lats = [p[1] for p in polygon_coords]
    
        # Plot the outline
        ax.plot(lons, lats, color='darkgrey', linewidth=0.7)
    
        # You can also fill the polygons if you prefer, but for outlines, plot is enough
        # from matplotlib.patches import Polygon
        # poly = Polygon(polygon_coords, closed=True, facecolor='lightgray', edgecolor='darkgrey', linewidth=0.7)
        # ax.add_patch(poly)


    # Set labels and title
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("Your Title")
    ax.set_xlim(-180, 180)
    ax.set_ylim(-90, 90)
    ax.grid(True, linestyle='--', alpha=0.6) # Adds light grid lines

    # Ensure proper aspect ratio for geographical data
    ax.set_aspect('equal', adjustable='box')    
    return fig, ax
